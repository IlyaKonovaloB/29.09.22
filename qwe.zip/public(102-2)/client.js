let div    = document.querySelector('div');
let button = document.querySelector('button');
let i =0;
let arr =["/ajax.html","/ajax1.html","/ajax2.html","/ajax3.html","/ajax4.html" ]
b1.addEventListener('click', function() {
  let s =arr[i];
	fetch(s).then(
		response => {
			return response.text();
		}
	).then(
		text => {
			div.innerHTML = text;
		}
	)
  i++;
  if (i > 4){i=0}
});
