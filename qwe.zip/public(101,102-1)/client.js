let div    = document.querySelector('div');
let button = document.querySelector('button');

b1.addEventListener('click', function() {
	fetch('/ajax.html').then(
		response => {
			return response.text();
		}
	).then(
		text => {
			div.innerHTML = text;
		}
	);
});
b2.addEventListener('click', function() {
	fetch('/ajax2.html').then(
		response => {
			return response.text();
		}
	).then(
		text => {
			div.innerHTML = text;
		}
	);
});
b3.addEventListener('click', function() {
	fetch('/ajax1.html').then(
		response => {
			return response.text();
		}
	).then(
		text => {
			div.innerHTML = text;
		}
	);
});